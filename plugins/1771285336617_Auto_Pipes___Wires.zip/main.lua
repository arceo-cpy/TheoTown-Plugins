-- Auto Pipes & Wires
-- Code created by: Sanjaya Adiputra (Javas100)
-- Do not change or delete the above credits !!

function script:enterCity()
  City.addRoadListener{
    draft = nil,
    added = function(data)
      local x, y = data.x, data.y
      if Builder.isPipeBuildable('$pipe00', x, y) then
        Builder.buildPipe('$pipe00', x, y, x, y)
      end
      if Builder.isWireBuildable('$underground_wire00', x, y) then
        Builder.buildWire('$underground_wire00', x, y, x, y)
      end
    end
  }
end